let vid;
function setup() {
  noCanvas();

  vid = createVideo(
    ['assets/feliz__navidad_saul.mp4', 'assets/trim.FCD7347F-7189-42CD-9EAE-21789985A929.ogv', 'assets/v12044gd0000cddgfbrc77ufelq46750.webm'],
    vidLoad
  );

  vid.size(400, 400);
}

function vidLoad() {
  vid.loop();
  vid.volume(1);
}
