fr = 30

function setup() {
  createCanvas(400, 400);
  frameRate(fr)
}

function draw() {
  background(220);
  colorMode(RGB,100);
  background(220);
  let x = mouseX
  let y = mouseY
  let px = pmouseX
  let py = pmouseY
  let eSize = 3;
  let eLoc = 10;
  stroke(50,20,0);
  fill(30,30,150);
  ellipse(x,y,80);
  fill(80,0,80)
  ellipse(sqrt(px) * 8,sqrt(py) * 8,120);
  fill(130,0,50);
  triangle(80,50,50,80,x,py)
}