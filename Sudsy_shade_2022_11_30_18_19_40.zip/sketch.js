function setup() {
  createCanvas(400, 400);
  ellipseMode(RADIUS);
  colorMode(RGB);
}

function draw() {
  background(224,250,144);
  rect(80,120,80,120);
  var radius = 30
  rect(240,120,80,120)
  ellipse(200,300,radius)
}

function keyPressed() {
  var d = dist(mouseX, mouseY, 200, 300);
  var radius = 30
  if ((keyIsPressed) && (d < radius)) {
    fill(224,94,85)
  }
  else {
	fill (152,190,250);
				}
					
}

function mousePressed() {
    background(224,250,144);
	if ((mouseX > 80) && (mouseX < 80+80) && (mouseY > 120) && (mouseY < 120+120)) {
		fill(151,173,83);
	}
	else {
		fill (152,190,250);
	if ((mouseX > 240) && (mouseX < 240+80) && (mouseY > 120) && (mouseY < 120+120)) {
		fill(173,102,92);
	}
	else {
		fill (152,190,250);
	}
    }
}